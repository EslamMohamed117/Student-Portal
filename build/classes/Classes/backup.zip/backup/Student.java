/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.sql.SQLException;

/**
 *
 * @author raya
 */
public class Student extends User {
    
    public String academicYear;
    public String classNo; 
    /**
     * 
     * @param ID 
     */
    public Student(String ID) {
        super(ID);
    }
    /**
     * 
     * @param academicYear
     * @param classNo
     * @param member 
     */
    public Student(String academicYear, String classNo, User member) {
        super(member);
        this.academicYear = academicYear;
        this.classNo = classNo;
    }
    /**
     * 
     * @param academicYear
     * @param classNo
     * @param age
     * @param phone
     * @param UserID
     * @param FirstName
     * @param LastName
     * @param birthDate
     * @param gender
     * @param password 
     */
    public Student(String academicYear, String classNo, String age, String phone, String UserID, String FirstName, String LastName, String birthDate, String gender) {
        super(age, phone, UserID, FirstName, LastName, birthDate, gender);
        this.academicYear = academicYear;
        this.classNo = classNo;
    }

    public String getAcademicYear() {
        return academicYear;
    }

    public void setAcademicYear(String academicYear) {
        this.academicYear = academicYear;
    }

    public String getClassNo() {
        return classNo;
    }

    public void setClassNo(String classNo) {
        this.classNo = classNo;
    }
    
    public void addStudent(){
        DB.addStudent(this);
        
    }
    public void updateStudent(){
        DB.updateStudent(this);
    }
    
    public static Student[] getStudent(){
        return DB.getStudents();
    }
    public void fillstudentInfo(){
        DB.getStudentInfo(this);
    } 
    
}
