/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author hp
 */
public class Activity {
    public String ActivityID ; 
    public String Name ;
    public String Type ; 
    public String Link ; 
    public String InstructorID;
    public String Date ;
    private final static DBInterface DB = new DBInterface();

    public Activity(String ActivityID, String Name, String Type, String Link, String InstructorID, String Date) {
        this.ActivityID = ActivityID;
        this.Name = Name;
        this.Type = Type;
        this.Link = Link;
        this.InstructorID = InstructorID;
        this.Date = Date;
    }
    
    public void createActivity(){
        DB.addActivity(this);
    }
    
    public void deleteActivity(String ID){
        DB.deleteActivity(this);
    }
    public void updateActivity(){
        //DB.UpdateActivity(this);
    }
    public static Activity[] getActivities(){
        return DB.getActivities();
    }
}
