/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author raya
 */
public class DBInterface {
    private static Connection con;
    private static String sql;
    private static Statement stmt;
    private static PreparedStatement pstmt;
    private static ResultSet rs;
    final static int STUDENT_TABLE = 0;   
    final static int STAFF_TABLE = 1;
    final static int COURSE_TABLE = 2;
    final static int ACTIVITY_TABLE = 3;
    
    public DBInterface() {
        try{
            DBInterface.con = DriverManager.getConnection("jdbc:derby://localhost:1527/SWproject", "root","12345");
            stmt = con.createStatement();
        }
        catch(SQLException e){
            System.out.println(e.getMessage());
        }
    }
    /**
     * 
     * @param tableType 
     */
    private void selectTable(int tableType){
        switch (tableType) {
            case STUDENT_TABLE:
                sql="select*from Student";//Page 26
                break;
        //x=1 or 2
            case STAFF_TABLE:
                sql="select*from Staff";//Page 26
                break;
            case COURSE_TABLE:
                sql="select*from Course";
                break;
            case ACTIVITY_TABLE:
                sql="select*from Activity";
                break;
            default:
                break;
        }
    }
    /**
     * 
     * @param tableType 
     */
    private void InsertIntoTable(int tableType){
         switch (tableType) {
            case STUDENT_TABLE:
                sql="insert into  Student";//Page 26
                break;
        //x=1 or 2
            case STAFF_TABLE:
                sql="insert into  Staff";//Page 26
                break;
            case COURSE_TABLE:
                sql="insert into Course";
                break;
            case ACTIVITY_TABLE:
                sql="insert into  Activity";
                break;
            default:
                break;
        
            }
    }
    /**
     * 
     * @param tableType 
     */    
    private void updateInTable(int tableType){
        switch (tableType) {
            case STUDENT_TABLE:
                sql="Update Student set FirstName=? , LastName=? ,gender=? , phone=? , birthDate=? ,age= ?, ClassNo = ?, Academicyear=? where ID=?";//Page 26
                break;//Please check class NO and Academic year Syntax!!!
            case STAFF_TABLE:
                sql="Update Staff set FirstName=? , LastName=? ,gender=? , phone=? , birthDate=? ,age= ?, salary = ?, coursecode = ? where ID=?  " ;
                break;
            default://The rest of cases should be implemented with each delete method added to the code.
                break;
        }
    }
    /**
     * 
     * @param tableType 
     */    
    private void deleteFromTable(int tableType){
        switch (tableType) {
            case STUDENT_TABLE:
                sql="DELETE FROM Student WHERE ID = ? ";//Page 26
                break;
            case STAFF_TABLE:
                sql="DELETE FROM Staff WHERE ID = ?  " ;
                break;
            case COURSE_TABLE:
                sql="DELETE FROM Course WHERE ID = ? ";
                break;
            case ACTIVITY_TABLE:
                sql="DELETE FROM Activity WHERE Code = ? ";
                break;
            default:
                break;
        }
    }
    /**
     * 
     * @param ID
     * @param password
     * @return
     * @throws SQLException 
     */
    public boolean checkUserCredentials(String ID, String password) {
        if(ID.startsWith("0"))
                selectTable(STUDENT_TABLE);
            else
                selectTable(STAFF_TABLE);
        try {    
            rs = stmt.executeQuery(sql);
            while(rs.next()){
                if(ID.equals(rs.getString("ID")) && password.equals(rs.getString("Password")))
                    return true;
            }
            return false;
        } 
        catch (SQLException ex) {
            Logger.getLogger(DBInterface.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
    /**
     * 
     * @param staffMember
     * @throws SQLException 
     */
    public void addStaff(Staff staffMember){
        InsertIntoTable(STAFF_TABLE);
        try {    
            addUser(staffMember);
            pstmt.setString(8, staffMember.salary);//testing
            pstmt.setString(9, staffMember.courseID);//testing
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DBInterface.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**
     * 
     * @param studentMember
     */
    public void addStudent(Student studentMember){
        InsertIntoTable(STUDENT_TABLE);
        try {    
            addUser(studentMember);
            pstmt.setString(8, studentMember.classNo);
            pstmt.setString(9, studentMember.academicYear);
            pstmt.executeUpdate();
        } 
        catch (SQLException ex) {
            Logger.getLogger(DBInterface.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**
     * 
     * @param member
     * @throws SQLException 
     */
    public void addUser(User member) throws SQLException{        //CommonData
        pstmt=con.prepareStatement(sql+ " Values(?,?,?,?,?,?,?,?,?,?)");//10 Parameters
        pstmt.setString(1, member.UserID       );
        pstmt.setString(2, member.FirstName);
        pstmt.setString(3, member.LastName );
        pstmt.setString(4, member.gender   );
        pstmt.setString(5, member.phone    );
        pstmt.setString(6, member.birthDate);
        pstmt.setString(7, member.age      );
        pstmt.setString(10,member.password );//move it to 8 in database later.
    }
    /**
     * 
     * @param course 
     */
    public void addCourse (Course course) {
        InsertIntoTable(COURSE_TABLE);
        try {
            pstmt=con.prepareStatement(sql + "  Values(?,?,?,?,?,?)");//6 Parameters
            pstmt.setString(1,course.courseID);
            pstmt.setString(2, course.name);
            pstmt.setString(3,course.instructorID);
            pstmt.setString(4,course.description);
            pstmt.executeUpdate();
            System.out.println("Data has been inserted!");//
        }
        catch(SQLException e) {
            System.out.println(e.toString());
        }
    }
    /**
     * 
     * @param activity 
     */
    public void addActivity (Activity activity) {
        InsertIntoTable(ACTIVITY_TABLE);
        try {
            pstmt=con.prepareStatement(sql + "  Values(?,?,?,?,?,?)");//6 Parameters
            pstmt.setString(1,activity.ActivityID);
            pstmt.setString(2,activity.Name);
            pstmt.setString(3,activity.Link);
            pstmt.setString(4,activity.Type);
            pstmt.setString(5,activity.InstructorID);
            pstmt.setString(6,activity.Date);
            pstmt.execute();
            System.out.println("Data has been inserted!");
        } 
        catch(SQLException e) {
            System.out.println(e.toString());
    // always remember to close database connections
        } 
    }
    /**
     * 
     * @param UserID
     * @param user
     * @throws SQLException 
     */ 
    public void deleteUser (String UserID){
        if (UserID.startsWith("0"))
            deleteFromTable(STUDENT_TABLE);
        else
            deleteFromTable(STAFF_TABLE);
        
        try{
        pstmt = con.prepareStatement(sql);
        pstmt.setString(1, UserID);
        pstmt.executeUpdate();
        //System.out.println("Data has been deleted!");//not true!!
        }
        catch (SQLException ex) {
            Logger.getLogger(DBInterface.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    /**
     * 
     * @param courseID
     */
    public void deleteCourse (String courseID){
        try {
            deleteFromTable(COURSE_TABLE);
            pstmt=con.prepareStatement(sql);
            pstmt.setString(1,courseID);
            pstmt.executeUpdate();
            //System.out.println("Data has been deleted!"); //not true!! 
        } catch (SQLException ex) {
            Logger.getLogger(DBInterface.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**
     * 
     * @param activity
     */
    public void deleteActivity(Activity activity){
        deleteFromTable(ACTIVITY_TABLE); 
        try{
            pstmt=con.prepareStatement(sql);
            pstmt.setString(1, activity.ActivityID);
            pstmt.executeUpdate();
        }
        catch(SQLException e){
            System.out.println(e.getMessage() + "\nActivity Couldn't be deleted");
        }
    }
    /**
     * 
     * @param std
     * 
     */
    public void updateStudent( Student std ){
        updateInTable(STUDENT_TABLE);
        try{
            pstmt=con.prepareStatement(sql);
            UpdateUser(std);
            pstmt.setString(8, std.classNo);// HAVE THIS BEEN ADDED TO THE DATA BASE TABLE?!?!
            pstmt.setString(9, std.academicYear);// HAVE THIS BEEN ADDED TO THE DATA BASE TABLE?!?!
            pstmt.execute(); 
            //System.out.println("Data has been updated!");
        }
        catch(SQLException ex){
            Logger.getLogger(DBInterface.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    /**
     * 
     * @param stf 
     */
    public void updateStaff( Staff stf ){
        updateInTable(STAFF_TABLE);
        try{    
            pstmt=con.prepareStatement(sql);
            UpdateUser(stf);
            pstmt.setString(8, stf.salary);  // HAS THIS BEEN ADDED TO THE DATA BASE TABLE?!?!
            pstmt.setString(9, stf.courseID );// HAS THIS BEEN ADDED TO THE DATA BASE TABLE?!?!
            pstmt.executeUpdate(); 
            //System.out.println("Data has been updated!");
        }
        catch(SQLException ex){
            Logger.getLogger(DBInterface.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**
     * 
     * @param usr
     * @throws SQLException 
     */
    public void UpdateUser(User usr) throws SQLException{
        pstmt.setString(1, usr.FirstName);
        pstmt.setString(2, usr.LastName ); 
        pstmt.setString(3, usr.gender   );
        pstmt.setString(4, usr.phone    );
        pstmt.setString(5, usr.birthDate); 
        pstmt.setString(6, usr.age      );
        pstmt.setString(7, usr.UserID       );
    }      
    /**
     * 
     * @return
     * @throws SQLException 
     */
    public Activity[] getActivities(){//please change this to be just liek the getStudents() Method and don't forget the ordering
        Activity act[] = new Activity[5];
        selectTable(ACTIVITY_TABLE);
        try {
        rs = stmt.executeQuery(sql);
        for(int i=0; i<5 && rs.next(); i++)
            act[i]=new Activity(
            rs.getString("Code"),
            rs.getString("Name"),
            rs.getString("Link"),
            rs.getString("Type"),
            rs.getString("InstructorID"),
            rs.getString("Date"));
        return act;
        } 
        catch (SQLException ex) {
            Logger.getLogger(DBInterface.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    /**
     * 
     * @return
     * @throws SQLException 
     */
    public Course[]   getCourses() {
        
        Course c[] = new Course[5];
        selectTable(COURSE_TABLE);
        try {
            rs = stmt.executeQuery(sql);//
            for(int i=0; i<5 && rs.next(); i++)
                c[i]=new Course(rs.getString("ID"), rs.getString("NAME"),
                        rs.getString("INSTRUCTORID"),
                        rs.getString("description"));
            return c;
            } 
        catch (SQLException ex) {
            Logger.getLogger(DBInterface.class.getName()).log(Level.SEVERE, null, ex);
        }
        return c;
    }
    /**
     * 
     * @return
     * @throws SQLException 
     */
    public Student[]  getStudents(){//IT WORKS!
        try {
        Student s[] = new Student[5];
        selectTable(STUDENT_TABLE);
        rs = stmt.executeQuery(sql);//
        for(int i=0; i<5 && rs.next(); i++)
            s[i]=new Student(
            rs.getString("ACADEMICYEAR"),
            rs.getString("CLASSNO"),
            rs.getString("AGE"),
            rs.getString("Phone"),
            rs.getString("ID"),
            rs.getString("FIRSTNAME"),
            rs.getString("LASTNAME"),
            rs.getString("BIRTHDATE"),
            rs.getString("GENDER"));   
        //s.length() returns the length of the array in case there were only 3 rows found
        return s;
        } 
        catch (SQLException ex) {
            Logger.getLogger(DBInterface.class.getName()).log(Level.SEVERE, null, ex);
        return null;
        }
    }
    public void getStudentInfo(Student s){//IT WORKS!
        try {
        selectTable(STUDENT_TABLE);
        sql+=" Where ID = ?";//
        pstmt = con.prepareStatement(sql);
        pstmt.setString(1, s.UserID);
        rs = pstmt.executeQuery();
        rs.next(); 
        s.academicYear= rs.getString("ACADEMICYEAR");
        s.classNo     = rs.getString("CLASSNO");
        s.age         = rs.getString("AGE");
        s.phone       = rs.getString("Phone");
        s.FirstName   = rs.getString("FIRSTNAME");
        s.LastName    = rs.getString("LASTNAME");
        s.birthDate   = rs.getString("BIRTHDATE");
        s.gender      = rs.getString("GENDER");
        //s.length() returns the length of the array in case there were only 3 rows found
        }
        catch (SQLException ex) {
            Logger.getLogger(DBInterface.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**
     * 
     * @return
     */
    public Staff[]    getStaff(){//IT WORKS!
        Staff stf[] = new Staff[5];
        selectTable(STUDENT_TABLE);
        try {
            rs = stmt.executeQuery(sql);//
            for(int i=0; i<5 && rs.next(); i++)
                stf[i]=new Staff(
                rs.getString("CourseID"),
                rs.getString("Salary"),
                rs.getString("AGE"), 
                rs.getString("Phone"),
                rs.getString("ID"), 
                rs.getString("FIRSTNAME"), 
                rs.getString("LASTNAME"),
                rs.getString("BIRTHDATE"), 
                rs.getString("GENDER")
            );
        }
        catch (SQLException ex) {
            Logger.getLogger(DBInterface.class.getName()).log(Level.SEVERE, null, ex);
        }
        //s.length() returns the length of the array in case there were only 3 rows found
    return stf;
    }
}
    