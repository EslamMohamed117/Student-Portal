/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author raya
 */
public class Staff extends User{
    protected String courseID;
    protected String salary;
    public Staff(String ID) {
        super(ID);
    }

    public Staff(String courseID, String salary, String age, String phone, String ID, String FirstName, String LastName, String birthDate, String gender) {
        super(age, phone, ID, FirstName, LastName, birthDate, gender);
        this.courseID = courseID;
        this.salary = salary;
    }

    
    /**
     *
     * @param member contains user Information
     * @param courseCode // A Foreign Key to Courses Table
     * @param salary    // Determines how much this staff member earns per month
     */
    public Staff(User member,String courseCode, String salary) {
        super(member);
        this.courseID = courseCode;
        this.salary = salary;
    }
    
    public void addStaff(){
        DB.addStaff(this);
        
    }
    public void updateStaff(){
        DB.updateStaff(this);
    }
    
    public static Staff[] getStaff(){
        return DB.getStaff();
    }
    
    public static void deleteStaff(String StaffID){
        //DB.deleteStaff(StaffID);
    }
    
    
}
